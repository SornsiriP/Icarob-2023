import gym
import torch
from simple_xarm.envs.xarm_env import XarmEnv
from stable_baselines3 import PPO
from stable_baselines3.common.env_checker import check_env
from stable_baselines3.common.vec_env import VecNormalize, DummyVecEnv
from stable_baselines3.common.callbacks import CheckpointCallback
from stable_baselines3.common.monitor import Monitor
from simple_xarm.resources.wrapper import ProcessFrame84,ImageToPyTorch

#tensorboard --logdir ./Mlp_log/
def main():
  log_dir = "./Mlp_log"
  env = XarmEnv()
  env = Monitor(env,log_dir)
  env = img_obs(env)

  observation = env.reset()

  model = first_train(env,log_dir)
  # model = cont_train(env,log_dir)

  while True:
    env.render()
    action, _state = model.predict(observation, deterministic=True)
    observation, reward, done, info = env.step(action)

    if done:
      observation = env.reset()
  env.close()

  

def first_train(env,log_dir):
  prefix = "Xarm_checkpoint_friction10"

  checkpoint_callback = CheckpointCallback(save_freq=50000, save_path=log_dir, name_prefix=prefix)
  model = PPO('MlpPolicy', env, verbose=1,learning_rate = 0.0003,batch_size=10,gamma=0.9995,tensorboard_log=log_dir,n_steps = 4000)
  model.learn(total_timesteps=500000,callback=[checkpoint_callback])
  model.save("PPO_grab")

  return model

def cont_train(env,log_dir):
  zip_name = "/Xarm_checkpoint_friction1000_500000_steps.zip"
  prefix = "Xarm_checkpoint_friction10_cont"

  checkpoint_callback = CheckpointCallback(save_freq=50000, save_path=log_dir, name_prefix=prefix)
  model = PPO.load(log_dir + zip_name)
  model.set_env(env)
  model.learn(total_timesteps=500000,callback=[checkpoint_callback])
  model.save("PPO_grab")

  return model

def img_obs(env):
  env = ProcessFrame84(env)  #for image
  env = DummyVecEnv([lambda: env]) 
  env = VecNormalize(env, norm_obs=True, norm_reward=True, clip_obs=10.)
  return env


if __name__ == '__main__':
  main()

